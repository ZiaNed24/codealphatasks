@extends('errors::minimal')

@section('title', __('Service not available'))
@section('message', __('Sorry, This demo site is unavailable right now.'))
