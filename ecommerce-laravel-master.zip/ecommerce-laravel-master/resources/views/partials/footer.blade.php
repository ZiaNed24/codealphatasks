<footer class="bg-dark">
    <div class="container bg-dark">
        <div class="footer">
            <div class="row">
                <div class="col-md-4">
                    <a href="#" class="footer-link">Privacy policy</a><br>
                    <a href="#" class="footer-link">Term and conditions</a><br>
                </div>
                <div class="col-md-4">
                    <h3>
                        Welcome to the site
                    </h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquam, assumenda. Culpa, libero.</p>
                </div>
                <div class="col-md-4">
                    <h3>
                        Contact:
                    </h3>
                    <p>Email: mohammedomer789@gmail.com</p>
                    <p>Website: <a href="https://mhmdomer.com">Personal Website</a></p>
                    <p>Github: <a href="https://github.com/mhmdomer">@mhmdomer</a></p>
                    <p>Twitter: <a href="https://twitter.com/mhmdomer_">@mhmdomer_</a></p>
                    <p>LinkedIn: <a href="https://linkedin.com/in/mohammed-omer-ali">Mohammed Omer</a></p>
                </div>
            </div>
        </div>
        <p>copyright &copy; Mohammed Omer Ali - All rights reserved 2019</p>
    </div>
</footer>
