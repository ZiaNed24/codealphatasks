<div class="container-fluid">
    <div class="row bg-light mt-3 rounded-4 p-4">
        
        <div class="col-lg-2 my-2 col-md-4 col-sm-4 col-xs-4 rounded-4 me-5">
            <ul class="list-group rounded-4 ">
                <li class="list-group-item bg-success"><strong><b><a href="admin_albums.php" onmouseover="lightter(this);" onmouseleave="darker(this);" class="text-decoration-none text-light bi bi-journal-album"> Albums</a></b></strong></li>
                <li class="list-group-item bg-success"><strong><b><a href="admin_artists.php" onmouseover="lightter(this);" onmouseleave="darker(this);" class="menu-hover text-decoration-none text-light bi bi-mic-fill">  Artists</a></b></strong></li>
                <li class="list-group-item bg-success"><strong><b><a href="admin_musics.php"onmouseover="lightter(this);" onmouseleave="darker(this);" class="menu-hover text-decoration-none text-light bi bi-file-earmark-music-fill">  Musics</a></b></strong></li>
            </ul>
        </div>


        