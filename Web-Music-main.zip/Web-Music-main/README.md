# <a href="http://farzadforuozanfar.ir/">faramusic.com</a>
# HOME 
![screencapture-faramusic-000webhostapp-index-php-2022-08-29-13_58_05](https://user-images.githubusercontent.com/91725214/187171010-187e558d-1766-47b6-bfe6-895fe01671e0.png)
# Albums
![screencapture-faramusic-000webhostapp-albums-php-2022-08-29-13_59_24](https://user-images.githubusercontent.com/91725214/187171055-4ac1c6d9-58da-44d4-a990-c263a7b1aa6b.png)
# Musics
![screencapture-faramusic-000webhostapp-musics-php-2022-08-29-13_59_03](https://user-images.githubusercontent.com/91725214/187171113-3e4e0747-ac1e-45b7-bfa3-1d7204b988cd.png)
# Artists
![screencapture-faramusic-000webhostapp-singers-php-2022-08-29-14_04_25](https://user-images.githubusercontent.com/91725214/187171922-6b868f58-bb8e-429c-8e14-03e44b6f4aeb.png)
# Albums Play music
![screencapture-faramusic-000webhostapp-musics-php-2022-08-29-14_06_47](https://user-images.githubusercontent.com/91725214/187172001-b92f8c50-59ad-459b-96ae-f956ea24e541.png)
# Musics Play
![Screenshot (619)](https://user-images.githubusercontent.com/91725214/187172085-7cf4091a-9729-405e-8c25-d066e2ed33f5.png)
